package com.anarghya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderModuleApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
