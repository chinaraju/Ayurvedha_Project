package com.anarghya.customer.ayur.exception;

/*Controller Class for Customer Controller
Author : Naveen Gopathi
*/

public class UserNotFoundException extends Exception{
	public UserNotFoundException(String s) {
		super(s);
	}
}
