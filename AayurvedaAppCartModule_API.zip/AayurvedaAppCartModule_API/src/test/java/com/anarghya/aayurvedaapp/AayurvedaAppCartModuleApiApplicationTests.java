package com.anarghya.aayurvedaapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AayurvedaAppCartModuleApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
