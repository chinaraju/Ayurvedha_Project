package snippet;

public class Snippet {
	public static void main(String[] args) {
		anarghya_commu_ordermodule
	}
}

